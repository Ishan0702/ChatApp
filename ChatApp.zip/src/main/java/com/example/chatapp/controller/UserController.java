package com.example.chatapp.controller;

import com.example.chatapp.ChatWebSocketHandler;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
public class UserController {

    @Autowired
    private ChatWebSocketHandler webSocketHandler; // ✅ Inject the actual bean

    // ✅ Fix usage to call non-static method on instance
    @GetMapping("/active-users")
    public List<String> getActiveUsers() {
        return webSocketHandler.getConnectedUsers();
    }

    // Optional: this endpoint might be redundant now
    @GetMapping("/users")
    public List<String> getUsers() {
        return webSocketHandler.getConnectedUsers();
    }
}
