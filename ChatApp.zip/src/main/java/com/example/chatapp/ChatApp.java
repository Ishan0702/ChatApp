package com.example.chatapp;

import javafx.application.Application;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.layout.*;
import javafx.stage.Stage;
import org.java_websocket.client.WebSocketClient;
import org.java_websocket.handshake.ServerHandshake;

import java.net.URI;
import java.text.SimpleDateFormat;
import java.util.Date;

//Add at the top:
import java.io.*;
import java.net.*;
import java.util.*;
import java.util.stream.Collectors;
import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.ObjectMapper;


public class ChatApp extends Application {

    private WebSocketClient webSocketClient;
    private VBox messagesBox;
    private String username;
    private String receiver;
    private ComboBox<String> receiverDropdown;  // Class-level now

    public static void main(String[] args) {
        launch(args);
    }
    
    private void showUserSelectionScreen(Stage stage) {
        Label userLabel = new Label("Logged in as: " + username);

        ComboBox<String> receiverDropdown = new ComboBox<>();
        receiverDropdown.setPromptText("Select user to chat with");

        // 🔄 Initial fetch of connected users
        List<String> activeUsers = fetchActiveUsers();
        activeUsers.remove(username);
        receiverDropdown.getItems().addAll(activeUsers);

        Button startChatButton = new Button("Start Chat");

        VBox selectionLayout = new VBox(15, userLabel, receiverDropdown, startChatButton);
        selectionLayout.setPadding(new Insets(20));
        selectionLayout.setAlignment(Pos.CENTER);

        Scene selectionScene = new Scene(selectionLayout, 300, 200);
        stage.setScene(selectionScene);

        startChatButton.setOnAction(e -> {
            String selectedReceiver = receiverDropdown.getValue();
            if (selectedReceiver != null && !selectedReceiver.equals(username)) {
                receiver = selectedReceiver;

                // 🔌 Connect to WebSocket and refresh dropdown after successful registration
                connectToWebSocket(() -> {
                    List<String> updatedUsers = fetchActiveUsers();
                    updatedUsers.remove(username);

                    // 🔁 Safely update dropdown in the JavaFX thread
                    javafx.application.Platform.runLater(() -> {
                        receiverDropdown.getItems().setAll(updatedUsers);
                        setupChatUI(stage);
                    });
                });

            } else {
                showAlert("Please select a valid user (not yourself)");
            }
        });
    }


    
    
    private void showAlert(String msg) {
        Alert alert = new Alert(Alert.AlertType.WARNING);
        alert.setTitle("Warning");
        alert.setContentText(msg);
        alert.showAndWait();
    }



    
    @Override
    public void start(Stage primaryStage) {
        TextField usernameField = new TextField();
        usernameField.setPromptText("Enter your username");
        Button nextButton = new Button("Next");

        VBox loginLayout = new VBox(10, usernameField, nextButton);
        loginLayout.setPadding(new Insets(20));
        loginLayout.setAlignment(Pos.CENTER);
        loginLayout.setPrefSize(300, 200);

        Scene loginScene = new Scene(loginLayout);
        primaryStage.setScene(loginScene);
        primaryStage.setTitle("Chat App - Login");
        primaryStage.show();

        nextButton.setOnAction(e -> {
            username = usernameField.getText().trim();
            if (!username.isEmpty()) {
                connectToWebSocket(() -> showUserSelectionScreen(primaryStage));
            }
        });
    }



    private void setupChatUI(Stage stage) {
        // Title label
        Label titleLabel = new Label("Spring WebSocket Chat Demo");
        titleLabel.setStyle("-fx-font-size: 20px; -fx-font-weight: bold; -fx-padding: 10px;");
        titleLabel.setAlignment(Pos.CENTER);

        // Chat interface
        messagesBox = new VBox(10);
        messagesBox.setPadding(new Insets(10));
        messagesBox.setStyle("-fx-background-color: #f4f4f4;");

        ScrollPane scrollPane = new ScrollPane(messagesBox);
        scrollPane.setFitToWidth(true);

        TextField messageField = new TextField();
        messageField.setPromptText("Type a message...");
        messageField.setPrefHeight(40);
        messageField.setStyle("-fx-font-size: 14px;");

        Button sendButton = new Button("Send");
        sendButton.setStyle("-fx-background-color: #4CAF50; -fx-text-fill: white; -fx-font-size: 14px;");
        sendButton.setPrefHeight(40);

        HBox inputBox = new HBox(10, messageField, sendButton);
        inputBox.setPadding(new Insets(10));
        inputBox.setAlignment(Pos.CENTER);
        HBox.setHgrow(messageField, Priority.ALWAYS);

        VBox chatLayout = new VBox(10, titleLabel, scrollPane, inputBox);
        chatLayout.setPrefSize(500, 600);

        Scene chatScene = new Scene(chatLayout);
        stage.setScene(chatScene);
        stage.setTitle("Chat App - " + username);

        sendButton.setOnAction(e -> {
            String message = messageField.getText().trim();
            if (!message.isEmpty()) {
                sendMessage(message);
                messageField.clear();
            }
        });
    }

    private void connectToWebSocket(Runnable onConnected) {
        try {
            webSocketClient = new WebSocketClient(new URI("ws://localhost:8080/chat")) {
                @Override
                public void onOpen(ServerHandshake handshakedata) {
                    System.out.println("✅ Connected to WebSocket server");

                    javafx.application.Platform.runLater(() -> {
                        if (onConnected != null) {
                            onConnected.run();
                        }

                        webSocketClient.send(username);
                        System.out.println("📤 Sent username: " + username);
                    });
                }

                @Override
                public void onMessage(String message) {
                    javafx.application.Platform.runLater(() -> {
                        try {
                            if (message.startsWith("{") && message.contains("\"type\":\"USER_LIST\"")) {
                                ObjectMapper mapper = new ObjectMapper();
                                Map<String, Object> jsonMap = mapper.readValue(message, new TypeReference<Map<String, Object>>() {});
                                List<String> users = (List<String>) jsonMap.get("users");

                                users.remove(username); // Remove self
                                if (receiverDropdown != null) {
                                    receiverDropdown.getItems().setAll(users);
                                }
                            } else {
                                displayMessage(message);
                            }
                        } catch (Exception e) {
                            e.printStackTrace();
                        }
                    });
                }

                @Override
                public void onClose(int code, String reason, boolean remote) {
                    System.out.println("❌ Disconnected: " + reason);
                }

                @Override
                public void onError(Exception ex) {
                    ex.printStackTrace();
                }
            };

            webSocketClient.connect();

        } catch (Exception e) {
            e.printStackTrace();
        }
    }









    private void sendMessage(String message) {
        if (webSocketClient != null && webSocketClient.isOpen()) {
            String timestamp = new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss").format(new Date());

            String json = String.format(
                "{\"sender\":\"%s\", \"receiver\":\"%s\", \"message\":\"%s\", \"timestamp\":\"%s\"}",
                username, receiver, message, timestamp
            );

            webSocketClient.send(json);
            // ❌ Remove local display (will come from server)
            // displayMessage("You: " + message);
        } else {
            System.out.println("WebSocket is not connected.");
        }
    }




    private void displayMessage(String message) {
        // Prevent displaying the same message twice
        if (!messagesBox.getChildren().isEmpty()) {
            Label last = (Label) messagesBox.getChildren().get(messagesBox.getChildren().size() - 1);
            if (last.getText().equals(message)) return;
        }

        Label messageLabel = new Label(message);
        messageLabel.setStyle("-fx-font-size: 14px; -fx-padding: 5px;");
        messagesBox.getChildren().add(messageLabel);
    }



private List<String> fetchActiveUsers() {
    try {
        URL url = new URL("http://localhost:8080/active-users");
        HttpURLConnection conn = (HttpURLConnection) url.openConnection();
        conn.setRequestMethod("GET");

        BufferedReader in = new BufferedReader(new InputStreamReader(conn.getInputStream()));
        String response = in.lines().collect(Collectors.joining());
        in.close();

        ObjectMapper mapper = new ObjectMapper();
        return mapper.readValue(response, new TypeReference<List<String>>() {});
    } catch (Exception e) {
        e.printStackTrace();
        return Collections.emptyList();
    }
} 
}

