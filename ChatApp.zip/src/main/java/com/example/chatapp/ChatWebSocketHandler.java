package com.example.chatapp;

import com.example.chatapp.model.ChatMessage;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.datatype.jsr310.JavaTimeModule;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.redis.core.RedisTemplate;
import org.springframework.stereotype.Component;
import org.springframework.web.socket.*;
import org.springframework.web.socket.handler.TextWebSocketHandler;

import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.*;

@Component
public class ChatWebSocketHandler extends TextWebSocketHandler {

    @Autowired
    private RedisTemplate<String, ChatMessage> redisTemplate;

    private final ObjectMapper objectMapper;

    // ✅ No longer static — let Spring manage the bean state
    private final Map<WebSocketSession, String> userSessions = new HashMap<>();
    private final Set<String> connectedUsers = Collections.synchronizedSet(new HashSet<>());

    public ChatWebSocketHandler() {
        System.out.println("💡 ChatWebSocketHandler bean is initialized!");
        objectMapper = new ObjectMapper();
        objectMapper.registerModule(new JavaTimeModule());
    }

    @Override
    public void afterConnectionEstablished(WebSocketSession session) {
        System.out.println("✅ New connection: " + session.getId());
    }

    @Override
    public void afterConnectionClosed(WebSocketSession session, CloseStatus status) {
        String username = userSessions.remove(session);
        if (username != null) {
            connectedUsers.remove(username);
            System.out.println("👋 Disconnected user: " + username);
        }
        System.out.println("❌ Connection closed: " + session.getId());
    }

    @Override
    protected void handleTextMessage(WebSocketSession session, TextMessage message) {
        try {
            String payload = message.getPayload().trim();
            System.out.println("📥 RAW PAYLOAD: " + payload);

            // ✅ Plain-text registration (not a JSON payload)
            if (!payload.startsWith("{")) {
                userSessions.put(session, payload);
                connectedUsers.add(payload);
                System.out.println("👤 Registered user: " + payload);
                broadcastUserList(); // 🔁 Notify all clients
                return;
            }


            // ✅ Process chat message
            ChatMessage chatMessage = objectMapper.readValue(payload, ChatMessage.class);
            chatMessage.setId(UUID.randomUUID());
            chatMessage.setTimestamp(LocalDateTime.now());

            String redisKey = "chat:" + chatMessage.getSender() + ":" + chatMessage.getReceiver();
            redisTemplate.opsForList().rightPush(redisKey, chatMessage);
            System.out.println("💾 Message saved to Redis → " + redisKey);

            String formatted = String.format(
                "%s → %s [%s]: %s",
                chatMessage.getSender(),
                chatMessage.getReceiver(),
                chatMessage.getTimestamp().toLocalTime().format(DateTimeFormatter.ofPattern("HH:mm:ss")),
                chatMessage.getMessage()
            );

            for (Map.Entry<WebSocketSession, String> entry : userSessions.entrySet()) {
                WebSocketSession s = entry.getKey();
                String user = entry.getValue();

                if (user.equals(chatMessage.getSender()) || user.equals(chatMessage.getReceiver())) {
                    if (s.isOpen()) {
                        s.sendMessage(new TextMessage(formatted));
                    }
                }
            }

        } catch (Exception e) {
            e.printStackTrace();
            try {
                session.sendMessage(new TextMessage("❌ Error: " + e.getMessage()));
            } catch (Exception innerEx) {
                innerEx.printStackTrace();
            }
        }
    }

    // ✅ Used by controller to get connected users
    public List<String> getConnectedUsers() {
        System.out.println("📡 Returning connected users: " + connectedUsers);
        return new ArrayList<>(connectedUsers);
    }
    
    private void broadcastUserList() {
        List<String> users = new ArrayList<>(connectedUsers);
        Map<String, Object> payload = new HashMap<>();
        payload.put("type", "USER_LIST");
        payload.put("users", users);

        try {
            String json = objectMapper.writeValueAsString(payload);

            for (WebSocketSession s : userSessions.keySet()) {
                if (s.isOpen()) {
                    s.sendMessage(new TextMessage(json));
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

}
